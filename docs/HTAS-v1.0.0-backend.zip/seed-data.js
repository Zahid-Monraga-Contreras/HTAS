const db = require('./src/db/database');
const bcrypt = require('bcrypt');

async function seedDatabase() {
    try {
        console.log('Iniciando seed de datos...\n');

        await db.query('BEGIN');

        // ============================================
        // DATOS DE PRUEBA
        // ============================================
        const doctores = [
            { nombre: 'Luis', apPaterno: 'Garcia', apMaterno: 'Mendoza', correo: 'doctor1@htas.com', especialidad: 'Cardiologia', cedula: 'DOC001', direccion: 'Av. Reforma 101', genero: 'Masculino' },
            { nombre: 'Ana', apPaterno: 'Martinez', apMaterno: 'Lopez', correo: 'doctor2@htas.com', especialidad: 'Neurologia', cedula: 'DOC002', direccion: 'Av. Insurgentes 202', genero: 'Femenino' },
            { nombre: 'Carlos', apPaterno: 'Hernandez', apMaterno: 'Garcia', correo: 'doctor3@htas.com', especialidad: 'Pediatria', cedula: 'DOC003', direccion: 'Calle Juarez 303', genero: 'Masculino' },
            { nombre: 'Maria', apPaterno: 'Lopez', apMaterno: 'Martinez', correo: 'doctor4@htas.com', especialidad: 'Ginecologia', cedula: 'DOC004', direccion: 'Av. Universidad 404', genero: 'Femenino' },
            { nombre: 'Jose', apPaterno: 'Gonzalez', apMaterno: 'Rodriguez', correo: 'doctor5@htas.com', especialidad: 'Ortopedia', cedula: 'DOC005', direccion: 'Calle Morelos 505', genero: 'Masculino' },
            { nombre: 'Patricia', apPaterno: 'Rodriguez', apMaterno: 'Fernandez', correo: 'doctor6@htas.com', especialidad: 'Dermatologia', cedula: 'DOC006', direccion: 'Av. Paseo 606', genero: 'Femenino' },
            { nombre: 'Miguel', apPaterno: 'Sanchez', apMaterno: 'Perez', correo: 'doctor7@htas.com', especialidad: 'Oftalmologia', cedula: 'DOC007', direccion: 'Calle Hidalgo 707', genero: 'Masculino' },
            { nombre: 'Laura', apPaterno: 'Ramirez', apMaterno: 'Torres', correo: 'doctor8@htas.com', especialidad: 'Psiquiatria', cedula: 'DOC008', direccion: 'Av. Reforma 808', genero: 'Femenino' },
            { nombre: 'Fernando', apPaterno: 'Torres', apMaterno: 'Gomez', correo: 'doctor9@htas.com', especialidad: 'Urologia', cedula: 'DOC009', direccion: 'Calle Juarez 909', genero: 'Masculino' },
            { nombre: 'Carmen', apPaterno: 'Flores', apMaterno: 'Cruz', correo: 'doctor10@htas.com', especialidad: 'Endocrinologia', cedula: 'DOC010', direccion: 'Av. Insurgentes 1010', genero: 'Femenino' }
        ];

        const pacientes = [
            { nombre: 'Juan', apPaterno: 'Perez', apMaterno: 'Gomez', correo: 'paciente1@htas.com', nss: 'NSS001', tipoSangre: 'O+', genero: 'Masculino' },
            { nombre: 'Maria', apPaterno: 'Lopez', apMaterno: 'Hernandez', correo: 'paciente2@htas.com', nss: 'NSS002', tipoSangre: 'A+', genero: 'Femenino' },
            { nombre: 'Carlos', apPaterno: 'Martinez', apMaterno: 'Garcia', correo: 'paciente3@htas.com', nss: 'NSS003', tipoSangre: 'B+', genero: 'Masculino' },
            { nombre: 'Ana', apPaterno: 'Gonzalez', apMaterno: 'Rodriguez', correo: 'paciente4@htas.com', nss: 'NSS004', tipoSangre: 'AB+', genero: 'Femenino' },
            { nombre: 'Luis', apPaterno: 'Rodriguez', apMaterno: 'Fernandez', correo: 'paciente5@htas.com', nss: 'NSS005', tipoSangre: 'O-', genero: 'Masculino' },
            { nombre: 'Laura', apPaterno: 'Sanchez', apMaterno: 'Perez', correo: 'paciente6@htas.com', nss: 'NSS006', tipoSangre: 'A-', genero: 'Femenino' },
            { nombre: 'Miguel', apPaterno: 'Ramirez', apMaterno: 'Torres', correo: 'paciente7@htas.com', nss: 'NSS007', tipoSangre: 'B-', genero: 'Masculino' },
            { nombre: 'Patricia', apPaterno: 'Torres', apMaterno: 'Gomez', correo: 'paciente8@htas.com', nss: 'NSS008', tipoSangre: 'AB-', genero: 'Femenino' },
            { nombre: 'Jose', apPaterno: 'Flores', apMaterno: 'Cruz', correo: 'paciente9@htas.com', nss: 'NSS009', tipoSangre: 'O+', genero: 'Masculino' },
            { nombre: 'Carmen', apPaterno: 'Cruz', apMaterno: 'Lopez', correo: 'paciente10@htas.com', nss: 'NSS010', tipoSangre: 'A+', genero: 'Femenino' }
        ];

        const acompanantes = [
            { nombre: 'Roberto', apPaterno: 'Gomez', apMaterno: 'Perez', correo: 'acomp1@htas.com', genero: 'Masculino' },
            { nombre: 'Sofia', apPaterno: 'Hernandez', apMaterno: 'Lopez', correo: 'acomp2@htas.com', genero: 'Femenino' },
            { nombre: 'Diego', apPaterno: 'Lopez', apMaterno: 'Martinez', correo: 'acomp3@htas.com', genero: 'Masculino' },
            { nombre: 'Valeria', apPaterno: 'Martinez', apMaterno: 'Garcia', correo: 'acomp4@htas.com', genero: 'Femenino' },
            { nombre: 'Andres', apPaterno: 'Garcia', apMaterno: 'Rodriguez', correo: 'acomp5@htas.com', genero: 'Masculino' },
            { nombre: 'Camila', apPaterno: 'Rodriguez', apMaterno: 'Fernandez', correo: 'acomp6@htas.com', genero: 'Femenino' },
            { nombre: 'Javier', apPaterno: 'Fernandez', apMaterno: 'Sanchez', correo: 'acomp7@htas.com', genero: 'Masculino' },
            { nombre: 'Daniela', apPaterno: 'Sanchez', apMaterno: 'Ramirez', correo: 'acomp8@htas.com', genero: 'Femenino' },
            { nombre: 'Ricardo', apPaterno: 'Ramirez', apMaterno: 'Torres', correo: 'acomp9@htas.com', genero: 'Masculino' },
            { nombre: 'Gabriela', apPaterno: 'Torres', apMaterno: 'Flores', correo: 'acomp10@htas.com', genero: 'Femenino' }
        ];

        const contrasenia = '12345678';
        const hash = await bcrypt.hash(contrasenia, 10);
        const pin = '123456';
        const idsDoctores = [];
        const idsPacientes = [];
        const idsAcompanantes = [];

        function generarCURP(index) {
            const letras = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            const numeros = '0123456789';
            let curp = '';

            for (let i = 0; i < 4; i++) {
                curp += letras.charAt(Math.floor(Math.random() * letras.length));
            }

            const idx = String(index + 1).padStart(6, '0');
            curp += idx;

            curp += letras.charAt(Math.floor(Math.random() * letras.length));
            curp += letras.charAt(Math.floor(Math.random() * letras.length));

            for (let i = 0; i < 4; i++) {
                curp += numeros.charAt(Math.floor(Math.random() * numeros.length));
            }

            return curp;
        }

        console.log('Creando 10 doctores...');
        for (let i = 0; i < doctores.length; i++) {
            const d = doctores[i];
            const curp = generarCURP(i);

            const result = await db.query(
                `INSERT INTO USUARIOS (
                    Nombre, ApPaterno, ApMaterno, Correo, Contrasenia, 
                    Rol, Telefono, Genero, PinVerificacion, PinVerificado,
                    FechaNacimiento, CURP, Activo
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
                RETURNING IdUsuario`,
                [
                    d.nombre, d.apPaterno, d.apMaterno, d.correo, hash,
                    'Doctor',
                    '55' + String(10000000 + i).padStart(8, '0'),
                    d.genero,
                    pin, true,
                    '1980-01-01',
                    curp,
                    true
                ]
            );

            const userId = result.rows[0].idusuario;
            idsDoctores.push(userId);

            await db.query(
                `INSERT INTO DOCTORES (IdUsuario, Cedula, ArchivoCedulaPDF, Especialidad, DireccionClinica)
                 VALUES ($1, $2, $3, $4, $5)`,
                [userId, d.cedula, 'data:application/pdf;base64,JVBERi0xLjQK', d.especialidad, d.direccion]
            );

            console.log('  Doctor ' + d.nombre + ' ' + d.apPaterno + ' creado (ID: ' + userId + ')');
        }

        console.log('\nCreando 10 pacientes...');
        for (let i = 0; i < pacientes.length; i++) {
            const p = pacientes[i];
            const curp = generarCURP(i + 10);

            const result = await db.query(
                `INSERT INTO USUARIOS (
                    Nombre, ApPaterno, ApMaterno, Correo, Contrasenia, 
                    Rol, Telefono, Genero, PinVerificacion, PinVerificado,
                    FechaNacimiento, CURP, Activo
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
                RETURNING IdUsuario`,
                [
                    p.nombre, p.apPaterno, p.apMaterno, p.correo, hash,
                    'Paciente',
                    '55' + String(20000000 + i).padStart(8, '0'),
                    p.genero,
                    pin, true,
                    '1990-01-01',
                    curp,
                    true
                ]
            );

            const userId = result.rows[0].idusuario;
            idsPacientes.push(userId);

            await db.query(
                `INSERT INTO PACIENTES (IdUsuario, NSS, TipoSangre)
                 VALUES ($1, $2, $3)`,
                [userId, p.nss, p.tipoSangre]
            );

            console.log('  Paciente ' + p.nombre + ' ' + p.apPaterno + ' creado (ID: ' + userId + ')');
        }

        console.log('\nCreando 10 acompanantes...');
        for (let i = 0; i < acompanantes.length; i++) {
            const a = acompanantes[i];
            const curp = generarCURP(i + 20);

            const result = await db.query(
                `INSERT INTO USUARIOS (
                    Nombre, ApPaterno, ApMaterno, Correo, Contrasenia, 
                    Rol, Telefono, Genero, PinVerificacion, PinVerificado,
                    FechaNacimiento, CURP, Activo
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
                RETURNING IdUsuario`,
                [
                    a.nombre, a.apPaterno, a.apMaterno, a.correo, hash,
                    'Acompañante',
                    '55' + String(30000000 + i).padStart(8, '0'),
                    a.genero,
                    pin, true,
                    '1985-01-01',
                    curp,
                    true
                ]
            );

            const userId = result.rows[0].idusuario;
            idsAcompanantes.push(userId);

            await db.query(
                `INSERT INTO ACOMPANANTES (IdUsuario, FechaAsignacion)
                 VALUES ($1, $2)`,
                [userId, new Date().toISOString().split('T')[0]]
            );

            console.log('  Acompanante ' + a.nombre + ' ' + a.apPaterno + ' creado (ID: ' + userId + ')');
        }

        await db.query('COMMIT');

        console.log('\n============================================');
        console.log('SEED COMPLETADO EXITOSAMENTE');
        console.log('============================================');
        console.log('\nResumen:');
        console.log('  Doctores creados: ' + idsDoctores.length);
        console.log('  Pacientes creados: ' + idsPacientes.length);
        console.log('  Acompanantes creados: ' + idsAcompanantes.length);
        console.log('\nCredenciales:');
        console.log('  Contrasena: 12345678');
        console.log('  PIN: 123456');
        console.log('\nCorreos de prueba:');
        console.log('  Doctores:');
        doctores.forEach((d) => console.log('    ' + d.correo + ' (' + d.genero + ')'));
        console.log('  Pacientes:');
        pacientes.forEach((p) => console.log('    ' + p.correo + ' (' + p.genero + ')'));
        console.log('  Acompanantes:');
        acompanantes.forEach((a) => console.log('    ' + a.correo + ' (' + a.genero + ')'));
        console.log('\n============================================');

    } catch (error) {
        await db.query('ROLLBACK');
        console.error('Error durante el seed:', error.message);
        console.error(error.stack);
    }
}

seedDatabase().then(() => {
    console.log('\nProceso finalizado');
    process.exit(0);
}).catch((error) => {
    console.error('Error fatal:', error);
    process.exit(1);
});