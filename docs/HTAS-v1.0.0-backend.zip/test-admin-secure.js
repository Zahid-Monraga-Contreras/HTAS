// Backend/test-admin-secure.js
const axios = require('axios');
const crypto = require('crypto');

const config = {
    baseUrl: 'http://localhost:3000',
    secretKey: process.env.DEV_SECRET_KEY || 'tu_clave_super_secreta_123456789'
};

async function createTestAdmin() {
    try {
        console.log('Creando administrador de desarrollo...\n');

        const response = await axios.post(
            `${config.baseUrl}/api/dev/create-test-admin`,
            {}, // Body vacío, la clave va en headers
            {
                headers: {
                    'secretKey': config.secretKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        console.log('¡Administrador creado exitosamente!');
        console.log('Datos del administrador:');
        console.log(`Correo: ${response.data.credentials.correo}`);
        console.log(`Contraseña: ${response.data.credentials.contrasenia}`);
        console.log(`PIN: ${response.data.credentials.pin}`);
        console.log(`ID: ${response.data.credentials.userId}`);

        // Guardar credenciales (añade este archivo al .gitignore)
        const fs = require('fs');
        const credentials = {
            ...response.data.credentials,
            created: new Date().toISOString(),
            environment: response.data.security.environment
        };
        fs.writeFileSync('.dev-admin-credentials.json', JSON.stringify(credentials, null, 2));
        console.log('\n Credenciales guardadas en .dev-admin-credentials.json');
        console.log(' Este archivo NO debe subirse a GitHub');

        return response.data;

    } catch (error) {
        console.error(' Error:', error.message);
        if (error.response) {
            console.error('Respuesta del servidor:', error.response.data);

            if (error.response.status === 403) {
                console.log('\n Soluciones:');
                console.log('1. Verifica que NODE_ENV=development en .env');
                console.log('2. Verifica que ALLOW_DEV_ENDPOINTS=true en .env');
                console.log('3. Asegúrate de que el servidor esté corriendo en localhost');
                console.log('4. La clave secreta debe coincidir con la del .env');
            }
        }
    }
}

// Ejecutar
createTestAdmin();