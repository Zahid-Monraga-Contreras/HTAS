# Script para sincronizar variables de entorno con Vercel
# Ejecutar desde: c:\Users\zahid\Documents\HTAS\Arquitectura\Backend

$vars = @{
    "DATABASE_URL"            = "postgresql://neondb_owner:npg_UVBA7rnfIx9T@ep-curly-grass-awy5tsp5-pooler.c-12.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
    "JWT_SECRET"              = "mi_secreto_super_seguro"
    "JWT_REFRESH_SECRET"      = "mi_refresh_secreto_super_seguro"
    "URL_FASTAPI"             = "https://htas-1wv5.onrender.com"
    "PYTHON_API_URL"          = "https://htas-1wv5.onrender.com"
    "URL_OLLAMA"              = "https://gave-subduing-lecturer.ngrok-free.dev"
    "EMAIL_USER"              = "20233l001139@utcv.edu.mx"
    "EMAIL_PASS"              = "mzrx bvdm mvpt nksj"
    "STRIPE_SECRET_KEY"       = "sk_test_51TF59VK1qKH77YTdlRgOPVRBYYnb7trNgaiMaT4PMm7mzktP9njxwePr8Wu6AlFVViN1fV307WALIAP4GgaWifPV00iIvuXJ7G"
    "STRIPE_PUBLISHABLE_KEY"  = "pk_test_51TF59VK1qKH77YTduyJn44BruhEDaWGDisu6ry0DtNKZwiTnFGyMysighKG4gecGIdX4TSFc66sike4gZoJ1xCXA008uHnREBG"
    "RECAPTCHA_SECRET_KEY"    = "6Le16bgtAAAAAKB_fMUu5X-xPkw6eqOCkcyKZ5zS"
    "RECAPTCHA_SITE_KEY"      = "6Le16bgtAAAAAFn_Dv1r9EBlQsIT3wcsAaNETRG2"
    "GOOGLE_CLIENT_ID"        = "1027809791786-nog2ic2td4gd0pc284td2lkgfa032kqm.apps.googleusercontent.com"
    "GOOGLE_CLIENT_SECRET"    = "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"
    "GOOGLE_REDIRECT_URI"     = "https://htas-backend.vercel.app/api/auth/google-fit/callback"
    "CLOUDINARY_CLOUD_NAME"   = "dd086bmjl"
    "CLOUDINARY_API_KEY"      = "475459429435142"
    "CLOUDINARY_API_SECRET"   = "THHyIEjsMXekTv9JtX0-KjxSCPc"
    "NODE_ENV"                = "production"
    "ALLOW_DEV_ENDPOINTS"     = "false"
    "PORT"                    = "3000"
    "VERCEL"                  = "1"
}

foreach ($key in $vars.Keys) {
    $value = $vars[$key]
    Write-Host "Configurando: $key" -ForegroundColor Cyan

    # Eliminar si ya existe (ignorar error si no existe)
    $null = npx vercel env rm $key production --yes 2>&1

    # Agregar nuevo valor
    $value | npx vercel env add $key production --yes 2>&1 | Out-Null

    if ($LASTEXITCODE -eq 0) {
        Write-Host "$key configurada correctamente" -ForegroundColor Green
    } else {
        Write-Host "Error en: $key" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Variables sincronizadas. Desplegando..." -ForegroundColor Green
npx vercel --prod --yes
