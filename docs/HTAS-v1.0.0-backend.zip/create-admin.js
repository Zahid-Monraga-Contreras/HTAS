const db = require('./src/db/database');
const bcrypt = require('bcrypt');

async function createAdmin() {
    try {
        const correo = `admin@htas.com`;
        const hash = await bcrypt.hash('12345678', 10);
        const pin = '123456';

        await db.query('BEGIN');

        const result = await db.query(
            `INSERT INTO USUARIOS (
                Nombre, ApPaterno, ApMaterno, Correo, Contrasenia, 
                Rol, Telefono, Genero, PinVerificacion, PinVerificado,
                FechaNacimiento, CURP, Activo
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
            RETURNING IdUsuario`,
            [
                "Admin", "Test", "Sistema", correo, hash,
                "Admin",
                "5512345678", "Masculino", pin, true,
                "1990-01-01", "PEAP900101HDFRRL01", true
            ]
        );

        const userId = result.rows[0].idusuario;

        await db.query(
            `INSERT INTO ADMINISTRADORES (IdUsuario, NivelPermiso, AreaResponsabilidad)
             VALUES ($1, $2, $3)`,
            [userId, "Soporte", "Sistemas"]
        );

        await db.query('COMMIT');

        console.log('Administrador creado exitosamente!');
        console.log('Correo:', correo);
        console.log('Contraseña:', '12345678');
        console.log('PIN:', pin);
        console.log('ID:', userId);

    } catch (error) {
        await db.query('ROLLBACK');
        console.error('Error:', error.message);
    }
}

createAdmin();